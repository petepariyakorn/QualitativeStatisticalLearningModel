Same as ExperimentsSet6Port but:
1) Write "rankstatnormal.R" as a function.
