##package mnormt for dmnorm
#require(mnormt);
##Input
#muvec<-newmuvec;
#sigmavec<-newsdvec;
#zcoefvec<-newzcoefvec;
##Low to high rank
#rankvec<-newrankvec;
statqual<-function(muvec, sigmavec, zcoefvec, rankvec){
  #Program param
  sdrangez<-10;
  deltaz<-0.01;
  dnum<-length(muvec);
  sdrange<-10;
  delta<-0.01*min(sigmavec);
  
  zvec<-seq(from=-sdrangez,to=sdrangez,by=deltaz);
  zlength<-length(zvec);
  exgzvec<-rep(0,length=zlength);
  for(k in 1:zlength){
  	z<-zvec[k];
  	maxmu<-max(abs(muvec+sigmavec*zcoefvec*z));#
  	maxsd<-max(sigmavec*sqrt(1-(zcoefvec^2)));
  	nextxvec<-seq(from=-maxmu-sdrange*maxsd,to=maxmu+sdrange*maxsd,by=delta);
  	lnextxvec<-c(nextxvec[1]-delta,nextxvec[1:(length(nextxvec)-1)]);
  	mnextxvec<-(nextxvec+lnextxvec)/2;
  	hvec<-rep(1,length=(length(nextxvec)+1));
  	#Length added by 1 to make hvec agree with hvec in other rounds
  	for (i in 1:(dnum-1)){
  		nowi<-rankvec[i];
  		nowzcoef<-zcoefvec[nowi];
  		nowmu<-muvec[nowi]+sigmavec[nowi]*nowzcoef*z;#
  		nowsd<-sigmavec[nowi]*sqrt(1-(nowzcoef^2));#
  		#Use mnextxvec to get the center point of each f(x)dx
  		#Synchronize all variable grids given the same z
  		size<-length(hvec);
  		mhvec<-(hvec[1:(size-1)]*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  					hvec[2:size]*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  		integrand<-mhvec*delta
  		hvec<-cumsum(integrand);
  		hvec<-c(hvec[1],hvec);
  	}
  	nowi<-rankvec[dnum];
  	nowzcoef<-zcoefvec[nowi];
  	nowmu<-muvec[nowi]+sigmavec[nowi]*nowzcoef*z;#
  	nowsd<-sigmavec[nowi]*sqrt(1-(nowzcoef^2));#
  	size<-length(hvec);
  	mhvec<-(hvec[1:(size-1)]*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  				hvec[2:size]*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  	integrand<-mhvec*delta
  	exgzvec[k]<-sum(integrand);
  }
  #prob<-sum(exgzvec*dnorm(zvec)*delta);
  livec<-1:(zlength-1);
  rivec<-2:zlength;
  prob<-sum(deltaz*(exgzvec[livec]*dnorm(zvec[livec])+exgzvec[rivec]*dnorm(zvec[rivec]))/2);
  
  exvec<-rep(NA,length=dnum);
  for(index in 1:dnum){
  	zvec<-seq(from=-sdrangez,to=sdrangez,by=deltaz);
  	zlength<-length(zvec);
  	exgzvec<-rep(0,length=zlength);
  	for(k in 1:zlength){
  		z<-zvec[k];
  		maxmu<-max(abs(muvec+sigmavec*zcoefvec*z));#
  		maxsd<-max(sigmavec*sqrt(1-(zcoefvec^2)));
  		nextxvec<-seq(from=-maxmu-sdrange*maxsd,to=maxmu+sdrange*maxsd,by=delta);
  		lnextxvec<-c(nextxvec[1]-delta,nextxvec[1:(length(nextxvec)-1)]);
  		mnextxvec<-(nextxvec+lnextxvec)/2;
  		hvec<-rep(1,length=(length(nextxvec)+1));
  		#Length added by 1 to make hvec agree with hvec in other rounds
  		for (i in 1:(dnum-1)){
  			nowi<-rankvec[i];
  			nowzcoef<-zcoefvec[nowi];
  			nowmu<-muvec[nowi]+sigmavec[nowi]*nowzcoef*z;#
  			nowsd<-sigmavec[nowi]*sqrt(1-(nowzcoef^2));#
  			#Use mnextxvec to get the center point of each f(x)dx
  			#Synchronize all variable grids given the same z
  			size<-length(hvec);
  			if (index==i){
  				mhvec<-(hvec[1:(size-1)]*lnextxvec*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  						hvec[2:size]*nextxvec*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  				integrand<-mhvec*delta;
  			}else{
  				mhvec<-(hvec[1:(size-1)]*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  						hvec[2:size]*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  				integrand<-mhvec*delta;
  			}
  			hvec<-cumsum(integrand);
  			hvec<-c(hvec[1],hvec);
  		}
  		nowi<-rankvec[dnum];
  		nowzcoef<-zcoefvec[nowi];
  		nowmu<-muvec[nowi]+sigmavec[nowi]*nowzcoef*z;#
  		nowsd<-sigmavec[nowi]*sqrt(1-(nowzcoef^2));#
  		size<-length(hvec);
  		if (index==dnum){
  			mhvec<-(hvec[1:(size-1)]*lnextxvec*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  						hvec[2:size]*nextxvec*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  			integrand<-mhvec*delta;
  		}else{
  			mhvec<-(hvec[1:(size-1)]*dnorm(lnextxvec,mean=nowmu,sd=nowsd)+
  						hvec[2:size]*dnorm(nextxvec,mean=nowmu,sd=nowsd))/2;
  			integrand<-mhvec*delta;
  		}
  		exgzvec[k]<-sum(integrand);
  	}
  	#exvec[rankvec[index]]<-sum(exgzvec*dnorm(zvec)*delta)/prob;
  	livec<-1:(zlength-1);
  	rivec<-2:zlength;
  	exvec[rankvec[index]]<-sum(deltaz*(exgzvec[livec]*dnorm(zvec[livec])+exgzvec[rivec]*dnorm(zvec[rivec]))/2)/prob;
  }
  return(exvec)
}