#Stat qual
#R codes to produce Figure Port
#Require rankstatnormal.R, return.csv, avefirmsize.csv and numfirm.csv
#Future ranking

library(mnormt)
returnframe<-read.csv(file="return.csv");
avefirmsizeframe<-read.csv(file="avefirmsize.csv");
numfirmframe<-read.csv(file="numfirm.csv");

#Check data integrity
#sum(ifelse(returnframe[,1]!=avefirmsizeframe[,1],1,0));
#sum(ifelse(avefirmsizeframe[,1]!=numfirmframe[,1],1,0));

returnmat<-as.matrix(returnframe[,-1])/100;
avefirmsizemat<-as.matrix(avefirmsizeframe[,-1]);
numfirmmat<-as.matrix(numfirmframe[,-1]);
capmat<-avefirmsizemat*numfirmmat;
valuevec<-rowSums(capmat);
wcapmat<-capmat/valuevec;

#Statqual function
source("rankstatnormal.R");

#Factor analysis function
sfn<-function(xvec){
	rmat<-returnmat[xvec,]
  rfa<-factanal(rmat, factors = 1)
  betavec<-rfa$loadings[,1]
  sigmamat<-betavec%*%t(betavec) + diag(rfa$uniquenesses)
  zcoefvec<-betavec/sqrt(diag(sigmamat));
  rsdvec<-apply(rmat,MARGIN=2,sd)
  #sigmamat above is a correlation matrix because x got standardized in factanal function
  #So, below we add the sd of X back into sigmamat to make it a covariance matrix
  sigmamat<-diag(rsdvec)%*%sigmamat%*%diag(rsdvec)
	return(list(sigmamat,betavec,zcoefvec));
}

#Loops to compute weight
###Parameter to be set
histlength<-66;
runstart<-1015;
###
#For 12 annual period, use runlength 144
#runlength<-144;
#For 2 annual period, use runlength 24
runlength<-24;
###
wmatp<-matrix(rep(NA,length=ncol(returnmat)*runlength),
					ncol=ncol(returnmat));
wmatqf<-matrix(rep(NA,length=ncol(returnmat)*runlength),
					ncol=ncol(returnmat));
mumatqf<-matrix(rep(NA,length=ncol(returnmat)*runlength),
                ncol=ncol(returnmat));
mumatp<-matrix(rep(NA,length=ncol(returnmat)*runlength),
               ncol=ncol(returnmat));
sigmalist<-list()

ptm<-Sys.time()
for(istar in runstart:(runstart+runlength-1)){
	winvec<-(istar-histlength):(istar-1);
	outsfn<-sfn(winvec);
	outsigmamat<-outsfn[[1]];
	outbetavec<-outsfn[[2]];
	outzcoefvec<-outsfn[[3]];

	###Qualitative Input
	newwcap<-wcapmat[istar-1,];
	newmuvec<-outsigmamat%*%newwcap;
	newmuvec<-sqrt(sum(returnmat[istar-1,]^2))*newmuvec/sqrt(sum(newmuvec^2));
	#Scale SD of the prior mean by 0.1
	newsdvec<-sqrt(0.1*diag(outsigmamat));
	newzcoefvec<-outzcoefvec;
	newrankvec<-order(returnmat[istar,]);
	###Low to high rank
	rankvec<-newrankvec;
	###Call statqual function to compute expectation given ranking
	exvec<-statqual(newmuvec, newsdvec, newzcoefvec, newrankvec);
	muqfvec<-exvec;
	wvec<-solve(outsigmamat,muqfvec);
	wvec<-wvec/sum(wvec);
	wmatqf[istar-runstart+1,]<-wvec;
	wmatp[istar-runstart+1,]<-newwcap;
	#save mu's and sigmamat
	mumatqf[istar-runstart+1,]<-muqfvec;
	mumatp[istar-runstart+1,]<-newmuvec;
	sigmalist<-c(sigmalist,list(outsigmamat))

	print(paste("istar : ",istar, ":: time : ", difftime(Sys.time(),ptm,units="mins")));
}

#Measure average returns from the weight
routwinmat<-returnmat[runstart:(runstart+runlength-1),];
rpvec<-rowSums(routwinmat*wmatp);
ravevec<-rowMeans(routwinmat);
rqfvec<-rowSums(routwinmat*wmatqf);
indexvec<-runstart:(runstart+runlength-1);

###Make changes here
#For 10 annual period
#periodvec<-sort(rep(1:10,12));
#For 2 annual period
periodvec <-sort(rep(1:(runlength/12),12))
###
rpbarvec<-tapply(rpvec,periodvec,mean);
rqfbarvec<-tapply(rqfvec,periodvec,mean);
s2pvec<-tapply(rpvec,periodvec,var);
s2qfvec<-tapply(rqfvec,periodvec,var);
ceqrpvec<-rpbarvec-0.5*s2pvec;
ceqrqfvec<-rqfbarvec-0.5*s2qfvec;

minceq<-min(c(ceqrpvec,ceqrqfvec));
maxceq<-max(c(ceqrpvec,ceqrqfvec));
plot(ceqrqfvec,type="l",ylim=c(minceq,maxceq*(1.5)),
xlab="Period", ylab="Certainty equivalence return");
points(ceqrpvec,type="l",lty=2);
legend("topleft",c("Rank constrained","Prior"),lty=c(1,2),bty="o");

